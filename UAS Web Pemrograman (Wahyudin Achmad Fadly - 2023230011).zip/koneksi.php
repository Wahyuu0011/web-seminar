<?php
// koneksi.php - File koneksi ke database di hosting

$host = "localhost"; // host database di hosting biasanya tetap localhost (cek dokumentasi jika beda)
$user = "ribg3268_unsada"; // username database yang lu buat di cPanel
$pass = "Sjtalj234567";    // password database yang lu set saat bikin user
$db   = "ribg3268_seminar_it"; // nama database di hosting (harus sama persis)

// Membuat koneksi ke MySQL
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi berhasil atau tidak
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error()); // tampilkan error kalau gagal
}

// echo "Koneksi berhasil!"; // Uncomment ini untuk ngetes koneksi manual
?>
