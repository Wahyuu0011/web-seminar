<?php
session_start(); // ✅ Session: Mulai session buat ngecek user yang login

// ✅ Branching: Cek apakah user udah login dan role-nya admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); // Redirect ke login kalau belum login / bukan admin
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- ✅ Tambahin ini biar responsif -->
  <title>Dashboard Admin - Seminar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .content {
      flex: 1;
      padding: 60px 15px;
    }

    .hero {
      background: linear-gradient(135deg, rgb(5, 139, 76), #6f42c1);
      color: white;
      padding: 60px 15px;
      text-align: center;
    }

    .hero h1 {
      font-size: 2rem;
      font-weight: bold;
    }

    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }

    .btn-custom {
      background-color: #198754;
      color: white;
      font-weight: 600;
      border-radius: 20px;
      padding: 10px 25px;
      transition: all 0.3s ease;
      display: inline-block;
    }

    .btn-custom:hover {
      background-color: #157347;
      transform: scale(1.05);
    }

    @media (max-width: 768px) {
      .hero h1 {
        font-size: 1.5rem;
      }

      .btn-custom {
        width: 100%;
        margin: 10px 0;
      }
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><b>Admin Panel</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
          <a class="nav-link d-flex align-items-center" href="logout.php">
            <i class="bi bi-box-arrow-right fs-6 me-2"></i>
            <span>Logout</span>
          </a>
        </li>
        <li class="nav-item"><a class="nav-link active" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_data.php">Data Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_kontak.php">Pesan</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <h1>Selamat Datang, Admin</h1>
  <p class="lead mt-3">Kelola data seminar nasional dengan mudah dan cepat.</p>
</section>

<!-- Konten -->
<div class="content container text-center">
  <h3 class="mb-4">Kelola Seminar:</h3>
  <a href="admin_data.php" class="btn btn-custom m-2">📋 Data Peserta</a>
  <a href="admin_sertifikat.php" class="btn btn-custom m-2">📄 Kelola Sertifikat</a>
  <a href="admin_jadwal.php" class="btn btn-custom m-2">🗓️ Atur Jadwal</a>
  <a href="admin_kontak.php" class="btn btn-custom m-2">📬 Pesan Kontak</a>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
