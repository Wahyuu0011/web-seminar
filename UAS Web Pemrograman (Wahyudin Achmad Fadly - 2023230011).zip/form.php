<?php
// daftar.php - Form pendaftaran peserta seminar + upload bukti follow IG

require 'koneksi.php'; // Koneksi ke database

$errors = [];  // ✅ Variabel array untuk nyimpan pesan error
$success = ""; // ✅ Variabel buat pesan sukses

// ✅ Branching + Request
// Cek apakah form disubmit pakai POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ✅ Variabel + Sanitasi Input
    $nama      = trim($_POST['nama']);
    $email     = trim($_POST['email']);
    $no_hp     = trim($_POST['no_hp']);
    $institusi = trim($_POST['institusi']);
    $follow_ig = isset($_POST['follow_ig']) ? true : false; // Checkbox follow IG

    // Validasi Input
    if (!$nama)      $errors[] = "Nama wajib diisi";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email tidak valid";
    if (!$no_hp)     $errors[] = "No HP wajib diisi";
    if (!$institusi) $errors[] = "Institusi wajib diisi";
    if (!$follow_ig) $errors[] = "Harus follow akun Instagram dulu";

    // Validasi File Upload
    if (!isset($_FILES['bukti_ig']) || $_FILES['bukti_ig']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = "Upload bukti follow IG gagal";
    } else {
        $file = $_FILES['bukti_ig'];
        $ext  = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png']; // Format yang diizinkan

        if (!in_array($ext, $allowed)) {
            $errors[] = "Format gambar harus JPG/PNG";
        }

        if ($file['size'] > 2 * 1024 * 1024) {
            $errors[] = "Ukuran file maksimal 2MB";
        }
    }

    // Kalau semua validasi aman
    if (empty($errors)) {
        $newName = uniqid('img_').'.'.$ext; // Nama unik file gambar
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true); // Bikin folder kalau belum ada
        move_uploaded_file($file['tmp_name'], $uploadDir.$newName); // Simpan file ke folder uploads

        // Insert Data ke Database (Prepared Statement)
        $stmt = mysqli_prepare($conn, "INSERT INTO peserta (nama, email, no_hp, institusi, bukti_ig) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'sssss', $nama, $email, $no_hp, $institusi, $newName);
        mysqli_stmt_execute($stmt);

        // Success Message
        $success = "Pendaftaran berhasil! Terima kasih sudah follow IG dan upload bukti.";
        $nama = $email = $no_hp = $institusi = ""; // Reset inputan
    }
}
?>

<!-- HTML + Bootstrap UI -->
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Daftar Seminar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      font-family:'Segoe UI',sans-serif;
      background: url('img/bg4.jpg') center/cover no-repeat;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .content {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 30px 15px;
    }
    .form-box {
      background: white;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 600px;
    }
    footer {
      background: #343a40;
      color: #fff;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>SeminarInTech</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item me-3"> <!-- Digeser ke kiri dikit -->
    <a class="nav-link d-flex align-items-center" href="login.php">
      <i class="bi bi-person-circle fs-6 me-2"></i>
      <span>Login</span>
    </a>
  </li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang</a></li>
        <li class="nav-item"><a class="nav-link active" href="form.php">Daftar</a></li>
        <li class="nav-item"><a class="nav-link" href="hasil.php">Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Konten Form -->
<div class="content">
  <div class="form-box">
    <h2 class="mb-4 text-center">Form Pendaftaran Seminar</h2>

    <!-- Tampilkan error kalau ada -->
    <?php if ($errors): ?>
      <div class="alert alert-danger">
        <?php foreach ($errors as $e) echo "<div>- $e</div>"; ?>
      </div>
    <?php endif; ?>

    <!-- Tampilkan pesan sukses -->
    <?php if ($success): ?>
      <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <!-- ✅ Form Input POST -->
    <form method="post" enctype="multipart/form-data">
      <div class="mb-3"><label>Nama Lengkap:</label><input type="text" name="nama" class="form-control" value="<?php echo @$nama; ?>"></div>
      <div class="mb-3"><label>Email:</label><input type="email" name="email" class="form-control" value="<?php echo @$email; ?>"></div>
      <div class="mb-3"><label>No HP:</label><input type="text" name="no_hp" class="form-control" value="<?php echo @$no_hp; ?>"></div>
      <div class="mb-3"><label>Institusi:</label><input type="text" name="institusi" class="form-control" value="<?php echo @$institusi; ?>"></div>

      <!-- Checkbox follow IG -->
      <div class="mb-3 form-check">
        <input type="checkbox" name="follow_ig" class="form-check-input" <?php echo isset($follow_ig)?'checked':''; ?>>
        <label class="form-check-label">Saya sudah follow akun IG @seminarin.tech</label>
      </div>

      <!-- Upload Gambar -->
      <div class="mb-3">
        <label>Bukti Follow IG (Screenshot):</label>
        <input type="file" name="bukti_ig" class="form-control">
      </div>

      <button type="submit" class="btn btn-primary w-100">Kirim Pendaftaran</button>
    </form>
  </div>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
