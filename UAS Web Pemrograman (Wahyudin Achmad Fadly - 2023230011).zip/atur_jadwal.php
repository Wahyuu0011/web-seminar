<?php
session_start(); // Mulai session buat cek login admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php"); // Kalau bukan admin, langsung tendang ke login
  exit;
}

require 'koneksi.php'; // Sambungin ke database

// Kalau form disubmit (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $judul   = $_POST['judul'];    // Ambil data judul
  $tanggal = $_POST['tanggal'];  // Ambil data tanggal
  $waktu   = $_POST['waktu'];    // Ambil data waktu
  $tempat  = $_POST['tempat'];   // Ambil data tempat

  // Query buat insert ke tabel jadwal
  $query = "INSERT INTO jadwal (judul, tanggal, waktu, tempat) VALUES ('$judul', '$tanggal', '$waktu', '$tempat')";
  
  // Kalau berhasil masukin ke database, balikin ke halaman admin_jadwal
  if (mysqli_query($conn, $query)) {
    header("Location: admin_jadwal.php");
    exit;
  } else {
    $error = "Gagal menambahkan jadwal."; // Kalau gagal, tampilin error
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- ✅ Biar responsif di HP -->
  <title>Tambah Jadwal - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(135deg,rgb(5, 139, 76), #6f42c1);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh; 
    }

    .content {
      flex: 1; 
      padding: 40px 20px;
      display: flex;
      justify-content: center; 
      align-items: center;     
    }

    .form-container {
      background: #ffffff;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 600px; 
    }

    footer {
      background-color: #343a40; 
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto; 
    }
  </style>
</head>
<body>

<!-- Navbar Admin -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><b>Admin Panel</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
          <a class="nav-link d-flex align-items-center" href="logout.php">
            <i class="bi bi-box-arrow-right fs-6 me-2"></i>
            <span>Logout</span>
          </a>
        </li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_data.php">Data Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link active" href="admin_jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_kontak.php">Pesan</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Form Tambah Jadwal -->
<div class="content">
  <div class="form-container">
    <?php if (isset($error)): ?>
      <div class="alert alert-danger"><?= $error ?></div> <!-- Tampilin pesan error kalau ada -->
    <?php endif; ?>

    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Judul Seminar</label>
        <input type="text" class="form-control" name="judul" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Tanggal</label>
        <input type="date" class="form-control" name="tanggal" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Waktu</label>
        <input type="time" class="form-control" name="waktu" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Tempat</label>
        <input type="text" class="form-control" name="tempat" required>
      </div>
      <div class="d-flex justify-content-between">
        <a href="admin_jadwal.php" class="btn btn-secondary">← Kembali</a>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
