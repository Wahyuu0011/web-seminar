<?php 
// ✅ OOP: Membuat class Peserta untuk CRUD peserta seminar
class Peserta {
    private $conn; // ✅ Variabel koneksi (akses private hanya bisa dipakai di class ini)

    // ✅ Constructor: otomatis jalan pas class dipanggil, nerima $db (koneksi)
    public function __construct($db) {
        $this->conn = $db; // Simpen koneksi ke dalam properti class
    }

    // ✅ Function: Ambil semua data peserta (SELECT * FROM peserta)
    public function getAll() {
        return mysqli_query($this->conn, "SELECT * FROM peserta ORDER BY id DESC");
    }

    // ✅ Function: Ambil data peserta berdasarkan ID
    public function getById($id) {
        // ✅ Prepared statement untuk mencegah SQL Injection
        $stmt = mysqli_prepare($this->conn, "SELECT * FROM peserta WHERE id = ?");
        mysqli_stmt_bind_param($stmt, 'i', $id); // i = integer
        mysqli_stmt_execute($stmt);
        return mysqli_stmt_get_result($stmt)->fetch_assoc(); // Ambil datanya sebagai array
    }

    // ✅ Function: Cari peserta berdasarkan nama atau institusi
    public function search($keyword) {
        $sql = "SELECT * FROM peserta WHERE nama LIKE ? OR institusi LIKE ? ORDER BY id DESC";
        $stmt = mysqli_prepare($this->conn, $sql);
        $like = "%{$keyword}%"; // Tambah wildcard buat LIKE
        mysqli_stmt_bind_param($stmt, 'ss', $like, $like); // s = string
        mysqli_stmt_execute($stmt);
        return mysqli_stmt_get_result($stmt); // Balikin hasil pencarian
    }

    // ✅ Function: Tambah peserta baru ke database (INSERT INTO)
    public function create($nama, $email, $no_hp, $institusi, $bukti) {
        $stmt = mysqli_prepare($this->conn, "INSERT INTO peserta (nama,email,no_hp, institusi,bukti_ig) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, 'sssss', $nama, $email, $no_hp, $institusi, $bukti); // semua string
        return mysqli_stmt_execute($stmt); // Eksekusi dan balikin true/false
    }

    // ✅ Function: Update data peserta
    public function update($id, $nama, $email, $no_hp, $institusi, $bukti = null) {
        if ($bukti) {
            // ✅ Update semua field termasuk bukti_ig
            $sql = "UPDATE peserta SET nama=?, email=?, no_hp=?, institusi=?, bukti_ig=? WHERE id=?";
            $stmt = mysqli_prepare($this->conn, $sql);
            mysqli_stmt_bind_param($stmt, 'sssssi', $nama, $email, $no_hp, $institusi, $bukti, $id);
        } else {
            // ✅ Kalau bukti kosong, gausah diubah
            $sql = "UPDATE peserta SET nama=?, email=?, no_hp=?, institusi=? WHERE id=?";
            $stmt = mysqli_prepare($this->conn, $sql);
            mysqli_stmt_bind_param($stmt, 'ssssi', $nama, $email, $no_hp, $institusi, $id);
        }
        return mysqli_stmt_execute($stmt); // Eksekusi update
    }

    // ✅ Function: Hapus data peserta
    public function delete($id) {
        // pake !! buat balikin boolean true/false
        return !!mysqli_query($this->conn, "DELETE FROM peserta WHERE id=$id");
    }
}
?>
