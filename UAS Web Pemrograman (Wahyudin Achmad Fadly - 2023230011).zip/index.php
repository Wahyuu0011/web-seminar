<?php
// index.php - Halaman utama peserta seminar
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Seminar Nasional IT 2025</title>

  <!-- Import Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Styling tambahan -->
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .content {
      flex: 1;
    }

    .hero {
      background: url('img/bg4.jpg') center/cover no-repeat;
      color: white;
      padding: 100px 20px;
      text-align: center;
      position: relative;
    }

    .hero h1 {
      font-size: 3rem;
      font-weight: bold;
    }

    .section {
      padding: 60px 20px;
    }

    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }

    .btn-custom {
      background-color: #0d6efd;
      color: white;
      font-weight: 600;
      border-radius: 20px;
      padding: 10px 25px;
      transition: all 0.3s ease;
    }

    .btn-custom:hover {
      background-color: #0b5ed7;
      transform: scale(1.05);
    }

    .card-icon {
      font-size: 2rem;
      color: #0d6efd;
      margin-bottom: 15px;
    }

    .testimonial-box {
      background: white;
      border-radius: 12px;
      padding: 30px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .logo-partner {
      max-width: 100px;
      margin: 10px;
      opacity: 0.7;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>SeminarInTech</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
  <ul class="navbar-nav me-auto">
    <li class="nav-item me-3"> <!-- Digeser ke kiri dikit -->
    <a class="nav-link d-flex align-items-center" href="login.php">
      <i class="bi bi-person-circle fs-6 me-2"></i>
      <span>Login</span>
    </a>
  </li>
    <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
    <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang</a></li>
    <li class="nav-item"><a class="nav-link" href="form.php">Daftar</a></li>
    <li class="nav-item"><a class="nav-link" href="hasil.php">Peserta</a></li>
    <li class="nav-item"><a class="nav-link" href="sertifikat.php">Sertifikat</a></li>
    <li class="nav-item"><a class="nav-link" href="jadwal.php">Jadwal</a></li>
    <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
    <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
  </ul>
</nav>

<!-- Konten Utama -->
<div class="content">

  <!-- Hero Section -->
  <section class="hero">
    <h1>Selamat Datang di SeminarInTech 2025</h1>
    <p class="lead mt-3">Gabung bersama para pakar teknologi dan kembangkan potensimu!</p>
    <a href="form.php" class="btn btn-custom mt-4">Daftar Sekarang</a>
  </section>

  <!-- Informasi Utama -->
  <section class="section text-center">
    <div class="container">
      <h2 class="mb-4">Kenapa Harus Ikut Seminar Ini?</h2>
      <div class="row">
        <div class="col-md-4">
          <div class="card-icon">🎤</div>
          <h5>Narasumber Ahli</h5>
          <p>Langsung dari para profesional dan akademisi teknologi.</p>
        </div>
        <div class="col-md-4">
          <div class="card-icon">📚</div>
          <h5>Materi Berkualitas</h5>
          <p>Topik yang relevan, aplikatif, dan mendalam.</p>
        </div>
        <div class="col-md-4">
          <div class="card-icon">📄</div>
          <h5>Sertifikat Resmi</h5>
          <p>Valid sebagai bukti keikutsertaan dan pengembangan diri.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Testimoni Peserta -->
  <section class="section bg-white">
    <div class="container">
      <h2 class="text-center mb-5">Apa Kata Peserta?</h2>
      <div class="row justify-content-center">
        <div class="col-md-5 testimonial-box text-center mb-4 mx-2">
          <p class="fw-bold">“Seminarnya keren banget, narasumbernya inspiratif!”</p>
          <p class="text-muted mb-0">- Wahyu, Mahasiswa IT</p>
        </div>
        <div class="col-md-5 testimonial-box text-center mb-4 mx-2">
          <p class="fw-bold">“Sertifikatnya bisa dipakai buat SKPI dan portofolio kerja.”</p>
          <p class="text-muted mb-0">- Fadly, Alumni IT</p>
        </div>
      </div>
    </div>
  </section>

</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
