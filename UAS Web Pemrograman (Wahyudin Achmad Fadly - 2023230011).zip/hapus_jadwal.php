<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

include 'koneksi.php';

if (!isset($_GET['id'])) {
  header("Location: admin_jadwal.php");
  exit;
}

$id = intval($_GET['id']);

// Hapus data
$query = mysqli_query($conn, "DELETE FROM jadwal WHERE id = $id");

if ($query) {
  header("Location: admin_jadwal.php?pesan=berhasil_hapus");
} else {
  echo "Gagal menghapus data.";
}
?>
