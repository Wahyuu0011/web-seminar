<?php
session_start(); // Mulai session buat nyimpen data login
include 'koneksi.php'; // Panggil file koneksi ke database

// Cek kalau tombol login ditekan
if (isset($_POST['login'])) {
    $username = $_POST['username']; // Ambil input username
    $password = md5($_POST['password']); // Enkripsi password pakai MD5 (harus sama kayak di DB)

    // Query buat nyocokin username dan password
    $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query); // Eksekusi query-nya

    // Kalau user valid
    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result); // Ambil datanya

        $_SESSION['username'] = $username; // Simpan username di session
        $_SESSION['admin'] = true; // ✅ Penting: Simpan session 'admin' biar halaman admin bisa diakses
        $_SESSION['role'] = $data['role'] ?? 'admin'; // Simpan role (kalau ga ada, default 'admin')

        setcookie("login_user", $username, time() + 3600); // Simpan cookie 1 jam

        header("Location: dashboard.php"); // Redirect ke dashboard
        exit; // Stop eksekusi biar ga lanjut render HTML
    } else {
        echo "<script>alert('Username / Password salah!');</script>"; // Tampil alert kalau salah
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login Admin - Seminar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <!-- Style tambahan buat layout -->
  <style>
    body {
      background: url('img/bg4.jpg') center/cover no-repeat;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    .login-container {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 30px 10px;
    }
    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }
    .login-card {
      background-color: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.25);
      width: 100%;
      max-width: 400px;
    }
    .login-header {
      background-color: #212529;
      padding: 15px;
      color: white;
      border-radius: 8px 8px 0 0;
      text-align: center;
      margin: -30px -30px 30px -30px;
    }
  </style>
</head>
<body>

<!-- Navbar tetap muncul -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>Seminar Teknologi</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item me-3"> <!-- Digeser ke kiri dikit -->
    <a class="nav-link d-flex align-items-center" href="login.php">
      <i class="bi bi-person-circle fs-6 me-2"></i>
      <span>Login</span>
    </a>
  </li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang</a></li>
        <li class="nav-item"><a class="nav-link" href="form.php">Daftar</a></li>
        <li class="nav-item"><a class="nav-link" href="hasil.php">Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Container buat tampilin form di tengah -->
<div class="login-container">
  <div class="login-card">
    <div class="login-header">
      <h3>Login Admin</h3>
    </div>
    <!-- Form login -->
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-4">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
    </form>
  </div>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<!-- Script Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
