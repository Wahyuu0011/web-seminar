<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

include 'koneksi.php';

if (!isset($_GET['id'])) {
  header("Location: admin_jadwal.php");
  exit;
}

$id = intval($_GET['id']);
$query = mysqli_query($conn, "SELECT * FROM jadwal WHERE id = $id");
$data = mysqli_fetch_assoc($query);

if (!$data) {
  echo "Data tidak ditemukan.";
  exit;
}

if (isset($_POST['submit'])) {
  $judul   = mysqli_real_escape_string($conn, $_POST['judul']);
  $tanggal = $_POST['tanggal'];
  $waktu   = $_POST['waktu'];
  $tempat  = mysqli_real_escape_string($conn, $_POST['tempat']);

  $update = mysqli_query($conn, "UPDATE jadwal SET 
    judul='$judul', tanggal='$tanggal', waktu='$waktu', tempat='$tempat'
    WHERE id=$id");

  if ($update) {
    header("Location: admin_jadwal.php?pesan=berhasil_update");
    exit;
  } else {
    echo "Gagal update data.";
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Jadwal - Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

      <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    html, body {
      height: 100%;
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }

    body {
      display: flex;
      background: linear-gradient(135deg,rgb(5, 139, 76), #6f42c1);
      flex-direction: column;
    }

    .main-content {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 30px 15px;
    }

    .card {
      width: 100%;
      max-width: 700px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 10px;
    }

    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><b>Admin Panel</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
  <a class="nav-link d-flex align-items-center" href="logout.php">
    <i class="bi bi-box-arrow-right fs-6 me-2"></i>
    <span>Logout</span>
  </a>
</li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_data.php">Data Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link active" href="admin_jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_kontak.php">Pesan</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Konten Tengah -->
<div class="main-content">
  <div class="card bg-white">
    <h4 class="mb-3">Edit Jadwal Seminar</h4>
    <form method="post">
      <div class="mb-3">
        <label for="judul" class="form-label">Judul</label>
        <input type="text" name="judul" id="judul" class="form-control" value="<?= htmlspecialchars($data['judul']) ?>" required>
      </div>
      <div class="mb-3">
        <label for="tanggal" class="form-label">Tanggal</label>
        <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?= $data['tanggal'] ?>" required>
      </div>
      <div class="mb-3">
        <label for="waktu" class="form-label">Waktu</label>
        <input type="time" name="waktu" id="waktu" class="form-control" value="<?= $data['waktu'] ?>" required>
      </div>
      <div class="mb-3">
        <label for="tempat" class="form-label">Tempat</label>
        <input type="text" name="tempat" id="tempat" class="form-control" value="<?= htmlspecialchars($data['tempat']) ?>" required>
      </div>
      <button type="submit" name="submit" class="btn btn-primary">Simpan</button>
      <a href="admin_jadwal.php" class="btn btn-secondary">Kembali</a>
    </form>
  </div>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>