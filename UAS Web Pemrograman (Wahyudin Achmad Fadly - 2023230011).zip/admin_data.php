<?php
session_start(); // ✅ Mulai session buat ngecek login

// ✅ Cek login dan role admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require 'koneksi.php';         // ✅ Koneksi database
require_once 'class/peserta.php'; // ✅ Include class Peserta

$peserta = new Peserta($conn); // ✅ Buat objek Peserta

// ✅ Hapus 1 peserta via GET
if (isset($_GET['hapus'])) {
    $peserta->delete($_GET['hapus']);
    header('Location: admin_data.php');
    exit;
}

// ✅ Hapus banyak peserta via POST
if (isset($_POST['hapus_terpilih']) && isset($_POST['id_terpilih'])) {
    foreach ($_POST['id_terpilih'] as $id) {
        $peserta->delete($id);
    }
    header('Location: admin_data.php');
    exit;
}

// ✅ Search peserta (kalau ada keyword)
$search = $_GET['search'] ?? '';
$res = $search ? $peserta->search($search) : $peserta->getAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- ✅ Tambahin biar responsive -->
  <title>Admin - Data Peserta</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .hero {
      background: linear-gradient(135deg, rgb(5, 139, 76), #6f42c1);
      color: white;
      padding: 60px 15px;
      text-align: center;
    }
    .content {
      flex: 1;
      padding: 30px 15px;
    }
    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
    }

    @media (max-width: 768px) {
      .hero h1 {
        font-size: 1.6rem;
      }
      .hero p {
        font-size: 1rem;
      }
      .table-responsive {
        font-size: 0.9rem;
      }
    }
  </style>
</head>
<body>

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><b>Admin Panel</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
          <a class="nav-link d-flex align-items-center" href="logout.php">
            <i class="bi bi-box-arrow-right fs-6 me-2"></i>
            <span>Logout</span>
          </a>
        </li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link active" href="admin_data.php">Data Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_kontak.php">Pesan</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- ✅ Hero Section -->
<section class="hero">
  <h1>Data Peserta Seminar</h1>
  <p class="lead mt-2">Kelola data peserta yang telah mendaftar seminar nasional.</p>
</section>

<!-- ✅ Konten -->
<div class="container content">

  <!-- ✅ Form search -->
  <form method="get" class="d-flex mb-3">
    <input name="search" class="form-control me-2" placeholder="Cari nama/institusi" value="<?=htmlspecialchars($search)?>">
    <button class="btn btn-primary me-2">Cari</button>
    <?php if($search): ?>
      <a href="admin_data.php" class="btn btn-secondary">Refresh</a>
    <?php endif; ?>
  </form>

  <!-- ✅ Form hapus terpilih -->
  <form method="post">
    <div class="mb-3 d-flex gap-3 align-items-center">
      <div class="form-check">
        <input type="checkbox" class="form-check-input" id="checkAll" onclick="toggleAll(this)">
        <label class="form-check-label" for="checkAll">Pilih Semua</label>
      </div>
      <button type="submit" name="hapus_terpilih" class="btn btn-danger btn-sm d-none" id="btnHapusTerpilih" onclick="return confirm('Yakin ingin menghapus yang dipilih?')">
        <i class="bi bi-trash"></i> Hapus Terpilih
      </button>
    </div>

    <div class="table-responsive">
      <table class="table table-bordered bg-white align-middle">
        <thead class="table-dark text-center">
          <tr>
            <th>#</th>
            <th>Pilih</th>
            <th>Nama</th>
            <th>Email</th>
            <th>No HP</th>
            <th>Institusi</th>
            <th>Bukti IG</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $no=1; while($row = mysqli_fetch_assoc($res)): ?>
          <tr>
            <td class="text-center"><?=$no++?></td>
            <td class="text-center">
              <input type="checkbox" class="form-check-input item-checkbox" name="id_terpilih[]" value="<?=$row['id']?>" onchange="toggleButton()">
            </td>
            <td><?=htmlspecialchars($row['nama'])?></td>
            <td><?=htmlspecialchars($row['email'])?></td>
            <td><?=htmlspecialchars($row['no_hp'])?></td>
            <td><?=htmlspecialchars($row['institusi'])?></td>
            <td class="text-center">
              <?= !empty($row['bukti_ig']) ? "<img src='uploads/{$row['bukti_ig']}' width='80'>" : '-' ?>
            </td>
            <td class="text-center">
              <a href="admin_data.php?hapus=<?=$row['id']?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus?')">Hapus</a>
            </td>
          </tr>
          <?php endwhile; ?>

          <?php if(mysqli_num_rows($res) == 0): ?>
            <tr><td colspan="8" class="text-center">Belum ada data</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </form>
</div>

<!-- ✅ Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<!-- ✅ Script -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleAll(source) {
  const checkboxes = document.querySelectorAll('.item-checkbox');
  checkboxes.forEach(cb => cb.checked = source.checked);
  toggleButton();
}
function toggleButton() {
  const btn = document.getElementById('btnHapusTerpilih');
  const anyChecked = document.querySelectorAll('.item-checkbox:checked').length > 0;
  btn.classList.toggle('d-none', !anyChecked);
}
</script>
</body>
</html>
