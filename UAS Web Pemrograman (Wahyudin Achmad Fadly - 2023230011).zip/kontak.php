<?php
// kontak.php - Halaman Kontak untuk peserta atau pengunjung seminar
include 'koneksi.php';

$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $pesan = $_POST['pesan'];

  // Validasi sederhana
  if (!empty($nama) && !empty($email) && !empty($pesan)) {
    $stmt = $conn->prepare("INSERT INTO pesan (nama, email, pesan) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nama, $email, $pesan);
    $stmt->execute();
    $success = true;
    $stmt->close();
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kontak Kami - Seminar IT</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(120deg, #e0eafc, #cfdef3);
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .content {
      flex: 1;
    }

    .hero-kontak {
      background: url('img/bg4.jpg') center/cover no-repeat;
      color: white;
      padding: 60px 20px;
      text-align: center;
    }

    .section {
      padding: 60px 20px;
    }

    .card-custom {
      background-color: white;
      border: none;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 15px;
    }

    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }

    .form-control:focus {
      box-shadow: none;
      border-color: #0d6efd;
    }

    .label-bold {
      font-weight: 500;
    }

    .alert-success {
      border-radius: 10px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>SeminarInTech</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item me-3"> <!-- Digeser ke kiri dikit -->
    <a class="nav-link d-flex align-items-center" href="login.php">
      <i class="bi bi-person-circle fs-6 me-2"></i>
      <span>Login</span>
    </a>
  </li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang</a></li>
        <li class="nav-item"><a class="nav-link" href="form.php">Daftar</a></li>
        <li class="nav-item"><a class="nav-link" href="hasil.php">Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
        <li class="nav-item"><a class="nav-link active" href="kontak.php">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero -->
<div class="hero-kontak">
  <h1>Hubungi Kami</h1>
  <p class="lead mt-2">Punya pertanyaan, saran, atau kendala? Kirim aja lewat form di bawah ini.</p>
</div>

<!-- Konten Utama -->
<div class="content">
  <section class="section">
    <div class="container">
      <div class="row g-4">
        
        <!-- Informasi Kontak -->
        <div class="col-md-5">
          <div class="card card-custom p-4">
            <h5 class="mb-3">📞 Informasi Kontak</h5>
            <p><span class="label-bold">Email:</span> seminartekno@kampus.ac.id</p>
            <p><span class="label-bold">Telepon:</span> +62 812-3456-7890</p>
            <p><span class="label-bold">Alamat:</span> Jl. Taman Malaka Selatan, Jakarta Timur, 13450</p>
            <p><span class="label-bold">Jam Operasional:</span> Senin - Jumat, 09.00 - 16.00</p>
          </div>
        </div>

        <!-- Form Kontak -->
        <div class="col-md-7">
          <div class="card card-custom p-4">
            <h5 class="mb-4">📬 Kirim Pesan ke Panitia</h5>

            <?php if ($success): ?>
              <div class="alert alert-success">✅ Pesan kamu berhasil dikirim!</div>
            <?php endif; ?>

            <form method="POST" action="">
              <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama lengkap Anda" required>
              </div>
              <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email aktif Anda" required>
              </div>
              <div class="mb-3">
                <label for="pesan" class="form-label">Pesan</label>
                <textarea class="form-control" id="pesan" name="pesan" rows="4" placeholder="Tulis pesan atau pertanyaan Anda..." required></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Kirim</button>
            </form>
          </div>
        </div>

      </div>
    </div>
  </section>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
