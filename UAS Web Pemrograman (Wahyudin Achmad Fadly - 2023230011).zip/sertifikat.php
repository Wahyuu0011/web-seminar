<?php
$dir = "file_sertifikat/"; // Direktori penyimpanan file
$sertifikat_files = array_diff(scandir($dir), array('.', '..')); // Ambil file kecuali . dan ..

$search = isset($_GET['search']) ? strtolower(trim($_GET['search'])) : '';

if ($search !== '') {
  $sertifikat_files = array_filter($sertifikat_files, function ($filename) use ($search) {
    return strpos(strtolower($filename), $search) !== false;
  });
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- ✅ Penting biar responsif -->
  <title>Sertifikat Seminar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .hero {
      background: url('img/bg4.jpg') center/cover no-repeat;
      color: white;
      padding: 60px 20px;
      text-align: center;
    }

    .content {
      flex: 1;
      padding: 40px 15px;
    }

    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
    }

    @media (max-width: 576px) {
      .hero h1 {
        font-size: 1.5rem;
      }

      .hero p {
        font-size: 1rem;
      }
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>SeminarInTech</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
          <a class="nav-link d-flex align-items-center" href="login.php">
            <i class="bi bi-person-circle fs-6 me-2"></i><span>Login</span>
          </a>
        </li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang</a></li>
        <li class="nav-item"><a class="nav-link" href="form.php">Daftar</a></li>
        <li class="nav-item"><a class="nav-link" href="hasil.php">Peserta</a></li>
        <li class="nav-item"><a class="nav-link active" href="sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <h1>Sertifikat SeminarInTech 2025</h1>
  <p class="lead mt-2">Silakan unduh sertifikat seminar Anda di bawah ini</p>
</section>

<!-- Konten -->
<div class="container-fluid content">

  <!-- Form Pencarian -->
  <form method="get" class="mb-4 d-flex flex-wrap gap-2">
    <input type="text" name="search" class="form-control me-2" placeholder="Cari nama sertifikat..." value="<?= htmlspecialchars($search) ?>">
    <button type="submit" class="btn btn-primary">Cari</button>
    <?php if ($search): ?>
      <a href="sertifikat.php" class="btn btn-secondary">Refresh</a>
    <?php endif; ?>
  </form>

  <?php if (empty($sertifikat_files)): ?>
    <div class="alert alert-warning text-center shadow-sm">
      📭 Sertifikat belum tersedia atau tidak ditemukan.
    </div>
  <?php else: ?>
    <!-- List Sertifikat -->
    <ul class="list-group shadow-sm">
      <?php foreach ($sertifikat_files as $file): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
          <span><?= htmlspecialchars($file) ?></span>
          <a href="download.php?file=<?= urlencode($file) ?>" class="btn btn-sm btn-success">
            <i class="bi bi-download me-1"></i> Download
          </a>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>

</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
