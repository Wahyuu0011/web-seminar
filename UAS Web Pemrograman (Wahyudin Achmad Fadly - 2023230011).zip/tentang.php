<?php
// tentang.php - Halaman Tentang Seminar Teknologi
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tentang Seminar</title>

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Icon Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .content {
      flex: 1;
    }
    .hero-tentang {
      background: url('img/bg4.jpg') center/cover no-repeat;
      color: white;
      padding: 80px 20px;
      text-align: center;
    }
    .section {
      padding: 60px 20px;
    }
    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }
    .icon-box {
      background: white;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 0 10px rgba(0,0,0,0.08);
      transition: transform .3s;
      height: 100%;
    }
    .icon-box:hover {
      transform: translateY(-5px);
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>SeminarInTech</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item me-3"> <!-- Digeser ke kiri dikit -->
    <a class="nav-link d-flex align-items-center" href="login.php">
      <i class="bi bi-person-circle fs-6 me-2"></i>
      <span>Login</span>
    </a>
  </li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link active" href="tentang.php">Tentang</a></li>
        <li class="nav-item"><a class="nav-link" href="form.php">Daftar</a></li>
        <li class="nav-item"><a class="nav-link" href="hasil.php">Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<div class="hero-tentang">
  <h1 class="display-5 fw-bold">Tentang SeminarInTech</h1>
  <p class="lead mt-3">Informasi umum tentang acara, penyelenggara, dan tujuan utama seminar ini.</p>
</div>

<!-- Content Section -->
<div class="content">
  <section class="section">
    <div class="container">
      <h2 class="mb-4 text-center">🎓 SeminarInTech 2025</h2>
      <p class="text-center mb-5">Seminar ini diselenggarakan oleh Program Studi Teknologi Informasi, bertujuan untuk mempertemukan akademisi, praktisi, dan mahasiswa dalam membahas tren terbaru di bidang teknologi.</p>

      <div class="row g-4">
        <!-- Box Tujuan Acara -->
        <div class="col-md-6">
          <div class="icon-box h-100">
            <h5><i class="bi bi-bullseye me-2 text-success"></i>Tujuan Acara</h5>
            <ul class="mt-3">
              <li>Memperluas wawasan tentang teknologi terbaru.</li>
              <li>Memberikan insight langsung dari pembicara profesional.</li>
              <li>Memotivasi mahasiswa untuk berinovasi di bidang IT.</li>
            </ul>
          </div>
        </div>

        <!-- Box Penyelenggara -->
        <div class="col-md-6">
          <div class="icon-box h-100">
            <h5><i class="bi bi-people-fill me-2 text-primary"></i>Penyelenggara</h5>
            <p class="mt-3">Seminar ini digagas oleh <b>Universitas Darma Persada</b>, dengan dukungan dari berbagai komunitas developer dan perusahaan startup nasional.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
