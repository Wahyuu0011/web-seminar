<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
  header("Location: login.php");
  exit;
}

// Ambil semua file dari folder file_sertifikat
$files = glob('file_sertifikat/*.*');
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- ✅ Biar responsif di HP -->
  <title>Admin - Sertifikat</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    main {
      flex: 1;
      padding: 40px 20px;
    }

    .hero {
      background: linear-gradient(135deg,rgb(5, 139, 76), #6f42c1);
      color: white;
      padding: 60px 20px;
      text-align: center;
    }

    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
    }

    .file-preview {
      background: white;
      padding: 15px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.05);
      margin-bottom: 15px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><b>Admin Panel</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
          <a class="nav-link d-flex align-items-center" href="logout.php">
            <i class="bi bi-box-arrow-right fs-6 me-2"></i>
            <span>Logout</span>
          </a>
        </li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_data.php">Data Peserta</a></li>
        <li class="nav-item"><a class="nav-link active" href="admin_sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_kontak.php">Pesan</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero -->
<section class="hero">
  <h1>Manajemen Sertifikat</h1>
  <p class="lead">Lihat dan kelola file sertifikat seminar nasional.</p>
</section>

<!-- Konten -->
<main class="container">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Sertifikat</h3>
    <a href="upload_sertifikat.php" class="btn btn-success">+ Upload Sertifikat</a>
  </div>

  <?php if (count($files) > 0): ?>
    <form method="post">
      <div class="mb-3 d-flex align-items-center gap-3">
        <div class="form-check">
          <input type="checkbox" class="form-check-input" id="checkAll" onclick="toggleAll(this)">
          <label for="checkAll" class="form-check-label">Pilih Semua</label>
        </div>
        <button type="submit" name="hapus_terpilih" class="btn btn-danger btn-sm d-none" id="btnHapusTerpilih" onclick="return confirm('Yakin ingin menghapus file yang dipilih?')">
          <i class="bi bi-trash"></i> Hapus Terpilih
        </button>
      </div>

      <div class="row">
        <?php foreach ($files as $file): ?>
          <div class="col-md-6 file-preview d-flex justify-content-between align-items-center">
            <div>
              <input type="checkbox" name="file_terpilih[]" value="<?= basename($file) ?>" class="form-check-input me-2 item-checkbox" onchange="toggleButton()">
              <?= basename($file) ?>
            </div>
            <div>
              <a href="<?= $file ?>" class="btn btn-primary btn-sm" target="_blank">Lihat</a>
              <a href="?hapus=<?= urlencode(basename($file)) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus sertifikat ini?')">Hapus</a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </form>
  <?php else: ?>
    <p class="text-muted">Belum ada file sertifikat yang diupload.</p>
  <?php endif; ?>

  <?php
  // ✅ Fitur hapus file sertifikat satuan
  if (isset($_GET['hapus'])) {
    $hapusFile = 'file_sertifikat/' . basename($_GET['hapus']);
    if (file_exists($hapusFile)) {
      unlink($hapusFile);
      echo "<script>window.location='admin_sertifikat.php';</script>";
    }
  }

  // ✅ Fitur hapus file terpilih
  if (isset($_POST['hapus_terpilih']) && isset($_POST['file_terpilih'])) {
    foreach ($_POST['file_terpilih'] as $hapus) {
      $fileHapus = 'file_sertifikat/' . basename($hapus);
      if (file_exists($fileHapus)) {
        unlink($fileHapus);
      }
    }
    echo "<script>window.location='admin_sertifikat.php';</script>";
  }
  ?>
</main>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- ✅ Script buat toggle checkbox dan tombol -->
<script>
// Centang/uncentang semua
function toggleAll(source) {
  const checkboxes = document.querySelectorAll('.item-checkbox');
  checkboxes.forEach(cb => cb.checked = source.checked);
  toggleButton(); // update tombol hapus
}

// Tampilkan tombol "hapus terpilih" jika minimal 1 checkbox dicentang
function toggleButton() {
  const anyChecked = document.querySelectorAll('.item-checkbox:checked').length > 0;
  const btn = document.getElementById('btnHapusTerpilih');
  btn.classList.toggle('d-none', !anyChecked);
}
</script>

</body>
</html>
