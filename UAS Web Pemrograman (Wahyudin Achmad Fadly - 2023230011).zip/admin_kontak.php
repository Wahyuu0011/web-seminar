<?php
// admin_kontak.php - Halaman admin untuk melihat pesan masuk

include 'koneksi.php'; // Koneksi ke database
$db = new mysqli("localhost", "ribg3268_unsada", "Sjtalj234567", "ribg3268_seminar_it");

if ($db->connect_error) {
  die("Koneksi gagal: " . $db->connect_error);
}

$result = $db->query("SELECT * FROM pesan ORDER BY waktu DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin - Pesan Masuk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .hero {
      background: linear-gradient(135deg,rgb(5, 139, 76), #6f42c1);
      color: white;
      padding: 50px 20px;
      text-align: center;
    }

    .content {
      flex: 1;
      padding: 40px 20px;
    }

    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .table thead {
      background-color: #212529;
      color: white;
    }

    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: auto;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><b>Admin Panel</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
  <a class="nav-link d-flex align-items-center" href="logout.php">
    <i class="bi bi-box-arrow-right fs-6 me-2"></i>
    <span>Logout</span>
  </a>
</li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_data.php">Data Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link active" href="admin_kontak.php">Pesan</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<div class="hero">
  <h1>Pesan Masuk</h1>
  <p class="lead">Cek pesan dari peserta atau pengunjung yang dikirim melalui form kontak</p>
</div>

<!-- Konten Utama -->
<div class="content container">
  <div class="card p-3">
    <div class="table-responsive">
      <table class="table table-striped table-bordered align-middle">
        <!-- Tambahan di bagian <thead> -->
<thead>
  <tr>
    <th>#</th>
    <th>Nama</th>
    <th>Email</th>
    <th>Pesan</th>
    <th>Waktu</th>
    <th>Aksi</th> <!-- Kolom baru -->
  </tr>
</thead>

<tbody>
  <?php if ($result->num_rows > 0): ?>
    <?php $no = 1; while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= nl2br(htmlspecialchars($row['pesan'])) ?></td>
        <td><?= $row['waktu'] ?></td>
        <td>
          <!-- Tombol Balas -->
          <a href="https://mail.google.com/mail/?view=cm&fs=1&to=<?= $row['email'] ?>&su=Balasan Pesan Seminar&body=Halo%20<?= urlencode($row['nama']) ?>,%0ATerima%20kasih%20atas%20pesanmu." 
             target="_blank" 
             class="btn btn-sm btn-outline-primary mb-1">
            <i class="bi bi-envelope-fill me-1"></i> Balas
          </a>

          <!-- Tombol Hapus -->
          <a href="hapus_pesan.php?id=<?= $row['id'] ?>" 
             class="btn btn-sm btn-outline-danger mb-1" 
             onclick="return confirm('Yakin ingin menghapus pesan ini?')">
            <i class="bi bi-trash-fill me-1"></i> Hapus
          </a>
        </td>
      </tr>
    <?php endwhile; ?>
  <?php else: ?>
    <tr><td colspan="6" class="text-center">Belum ada pesan masuk.</td></tr>
  <?php endif; ?>
</tbody>


      </table>
    </div>
  </div>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
