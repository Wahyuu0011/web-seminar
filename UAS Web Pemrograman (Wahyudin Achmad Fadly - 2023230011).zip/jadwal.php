<?php
require 'koneksi.php'; // Panggil koneksi ke database

// Ambil semua data dari tabel jadwal, urutkan dari tanggal terdekat
$jadwal = mysqli_query($conn, "SELECT * FROM jadwal ORDER BY tanggal ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Jadwal Seminar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CDN buat styling -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .hero {
      background: url('img/bg4.jpg') center/cover no-repeat;
      color: white;
      padding: 60px 20px;
      text-align: center;
    }
    .content {
      flex: 1;
      padding: 40px 20px;
    }
    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
    }
  </style>
</head>
<body>

<!-- Navbar biar konsisten -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>SeminarInTech</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item me-3"> <!-- Digeser ke kiri dikit -->
    <a class="nav-link d-flex align-items-center" href="login.php">
      <i class="bi bi-person-circle fs-6 me-2"></i>
      <span>Login</span>
    </a>
  </li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang</a></li>
        <li class="nav-item"><a class="nav-link" href="form.php">Daftar</a></li>
        <li class="nav-item"><a class="nav-link" href="hasil.php">Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link active" href="jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<div class="hero">
  <h1>Jadwal Seminar</h1>
  <p class="lead">Lihat daftar jadwal seminar yang akan datang, lengkap dengan tanggal dan tempat pelaksanaannya.</p>
</div>

<!-- Konten utama jadwal -->
<div class="container content">

  <?php if (mysqli_num_rows($jadwal) > 0): ?>
    <!-- Kalau ada jadwalnya, tampilkan tabel -->
    <div class="table-responsive">
      <table class="table table-bordered align-middle bg-white">
        <thead class="table-success text-center">
          <tr>
            <th>#</th>
            <th>Judul</th>
            <th>Tanggal</th>
            <th>Waktu</th>
            <th>Tempat</th>
          </tr>
        </thead>
        <tbody>
          <?php $no = 1; while($row = mysqli_fetch_assoc($jadwal)): ?>
            <tr>
              <td class="text-center"><?= $no++ ?></td> <!-- 🔢 No urut -->
              <td><?= htmlspecialchars($row['judul']) ?></td> <!-- 📝 Judul seminar -->
              <td class="text-center"><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td> <!-- 📆 Tanggal -->
              <td class="text-center"><?= htmlspecialchars($row['waktu']) ?></td> <!-- 🕐 Waktu -->
              <td><?= htmlspecialchars($row['tempat']) ?></td> <!-- 🏢 Tempat -->
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <!-- ❌ Kalau belum ada data jadwal -->
    <p class="text-center">Belum ada jadwal yang tersedia.</p>
  <?php endif; ?>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
