<?php
// koneksi ke database
require 'koneksi.php';

// Ambil keyword pencarian (kalau ada)
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';

// Cek apakah keyword diisi, kalau iya maka cari berdasarkan nama/institusi
if ($keyword !== '') {
    $sql = "SELECT * FROM peserta WHERE nama LIKE ? OR institusi LIKE ? ORDER BY tanggal_daftar DESC";
    $like = "%{$keyword}%";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'ss', $like, $like);
} else {
    // Kalau gak ada keyword, ambil semua data peserta
    $stmt = mysqli_prepare($conn, "SELECT * FROM peserta ORDER BY tanggal_daftar DESC");
}

// Eksekusi query dan ambil hasil
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Daftar Peserta Seminar</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    body { font-family:'Segoe UI',sans-serif; background:#f8f9fa; display:flex; flex-direction:column; min-height:100vh; }
    .hero {
      background: url('img/bg4.jpg') center/cover no-repeat;
      color: white;
      padding: 60px 20px;
      text-align: center;
    }
    .content { flex:1; padding:40px 20px; }
    footer { background:#343a40; color:#fff; text-align:center; padding:15px 0; margin-top:auto; }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>SeminarInTech</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item me-3"> <!-- Digeser ke kiri dikit -->
    <a class="nav-link d-flex align-items-center" href="login.php">
      <i class="bi bi-person-circle fs-6 me-2"></i>
      <span>Login</span>
    </a>
  </li>
        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang</a></li>
        <li class="nav-item"><a class="nav-link" href="form.php">Daftar</a></li>
        <li class="nav-item"><a class="nav-link active" href="hasil.php">Peserta</a></li>
        <li class="nav-item"><a class="nav-link" href="sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
        <li class="nav-item"><a class="nav-link" href="kontak.php">Kontak</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <h1>Peserta SeminarInTech 2025</h1>
  <p class="lead">Berikut adalah daftar peserta yang telah terdaftar resmi</p>
</section>

<!-- Konten -->
<div class="content container">

  <!-- Form Pencarian -->
  <form method="get" class="mb-4">
    <div class="input-group">
      <input type="text" name="keyword" class="form-control" placeholder="Cari nama atau institusi..." value="<?php echo htmlspecialchars($keyword); ?>">
      <button class="btn btn-primary">Cari</button>
      <?php if ($keyword): ?>
        <a href="hasil.php" class="btn btn-secondary">Refresh</a>
      <?php endif; ?>
    </div>
  </form>

  <!-- Tabel Peserta -->
  <table class="table table-striped table-bordered shadow-sm">
    <thead class="table-dark">
      <tr>
        <th>#</th>
        <th>Nama</th>
        <th>Institusi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      while ($row = mysqli_fetch_assoc($res)): ?>
        <tr>
          <td><?php echo $no++; ?></td>
          <td><?php echo htmlspecialchars($row['nama']); ?></td>
          <td><?php echo htmlspecialchars($row['institusi']); ?></td>
        </tr>
      <?php endwhile; ?>
      <?php if ($no === 1): ?>
        <tr><td colspan="3" class="text-center">Belum ada data peserta.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
