<?php
session_start();
if (!isset($_SESSION['admin'])) {
  header("Location: login.php");
  exit;
}

$upload_success = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["sertifikat"])) {
  $target_dir = "file_sertifikat/";
  $allowed_types = ['pdf', 'jpg', 'jpeg', 'png'];

  $total = count($_FILES["sertifikat"]["name"]);
  $success = 0;
  $errors = [];

  for ($i = 0; $i < $total; $i++) {
    $fileName = basename($_FILES["sertifikat"]["name"][$i]);
    $fileTmp = $_FILES["sertifikat"]["tmp_name"][$i];
    $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (in_array($fileType, $allowed_types)) {
      $target_file = $target_dir . time() . '_' . $fileName;

      if (move_uploaded_file($fileTmp, $target_file)) {
        $success++;
      } else {
        $errors[] = "❌ Gagal upload <b>$fileName</b>.";
      }
    } else {
      $errors[] = "❌ Format tidak diizinkan untuk <b>$fileName</b>.";
    }
  }

  $upload_success .= "✅ Berhasil upload $success file.<br>";
  if (!empty($errors)) {
    $upload_success .= implode('<br>', $errors);
  }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Upload Sertifikat - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg,rgb(5, 139, 76), #6f42c1);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .hero {
      background: linear-gradient(135deg,rgb(5, 139, 76), #6f42c1);
      color: white;
      padding: 60px 20px;
      text-align: center;
    }
    .content {
      flex: 1;
      padding: 40px 20px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .upload-container {
      background: #ffffff;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 600px;
    }
    h2 {
      font-weight: bold;
      margin-bottom: 25px;
      color: #343a40;
    }
    .btn-custom {
      background-color: #198754;
      color: white;
      font-weight: 600;
      border-radius: 30px;
      padding: 10px 25px;
      transition: all 0.3s ease;
    }
    .btn-custom:hover {
      background-color: #198754;
      transform: scale(1.05);
    }
    footer {
      background-color: #343a40;
      color: white;
      text-align: center;
      padding: 15px 0;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><b>Admin Panel</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarAdmin">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarAdmin">
      <ul class="navbar-nav">
        <li class="nav-item me-3">
          <a class="nav-link d-flex align-items-center" href="logout.php">
            <i class="bi bi-box-arrow-right fs-6 me-2"></i>
            <span>Logout</span>
          </a>
        </li>
        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_data.php">Data Peserta</a></li>
        <li class="nav-item"><a class="nav-link active" href="admin_sertifikat.php">Sertifikat</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_jadwal.php">Jadwal</a></li>
        <li class="nav-item"><a class="nav-link" href="admin_kontak.php">Pesan</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Konten -->
<div class="content">
  <div class="upload-container">
    <h2 class="text-center">Upload Sertifikat Seminar</h2>

    <?php if (!empty($upload_success)): ?>
      <div class="alert alert-info"><?= $upload_success ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="sertifikat" class="form-label">Pilih file sertifikat (PDF/JPG/PNG, bisa banyak):</label>
        <input class="form-control" type="file" name="sertifikat[]" id="sertifikat" multiple required>
      </div>
      <div class="d-flex justify-content-between mt-4">
        <a href="admin_sertifikat.php" class="btn btn-secondary">← Kembali</a>
        <button type="submit" class="btn btn-custom">Upload Sertifikat</button>
      </div>
    </form>
  </div>
</div>

<!-- Footer -->
<footer>
  <p class="mb-0">&copy; UAS Web Pemrograman - Wahyudin Achmad Fadly (2023230011)</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
