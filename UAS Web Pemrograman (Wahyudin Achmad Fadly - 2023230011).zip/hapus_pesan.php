<?php
// hapus_pesan.php - untuk menghapus pesan

include 'koneksi.php';
$db = new mysqli("localhost", "ribg3268_unsada", "Sjtalj234567", "ribg3268_seminar_it");

if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  $query = $db->query("DELETE FROM pesan WHERE id = $id");

  if ($query) {
    header("Location: admin_kontak.php?msg=deleted");
  } else {
    echo "Gagal menghapus data.";
  }
} else {
  echo "ID tidak ditemukan.";
}
?>
