<?php
session_start(); // Mulai session dulu (biar bisa dihancurin)

session_destroy(); // Hancurin semua data session (logout beneran)

setcookie("login_user", "", time() - 3600); // Hapus cookie dengan cara atur waktunya ke masa lalu

header("Location: login.php"); // Setelah logout, langsung balik ke halaman login

exit; // Hentikan script biar ga ngelanjutin proses lain
?>
